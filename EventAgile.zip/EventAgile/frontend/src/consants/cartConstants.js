export const ADD_TO_CART = "ADD_TO_CART";
export const SAVE_TIMING_INFO = "SAVE_TIMING_INFO";
export const REMOVE_CART_ITEM = "REMOVE_CART_ITEM";

export const ADD_TO_CAT = "ADD_TO_CAT";
export const REMOVE_CAT_ITEM = "REMOVE_CAT_ITEM";

export const ADD_TO_DECO = "ADD_TO_DECO";
export const REMOVE_DECO_ITEM = "REMOVE_DECO_ITEM";

export const DATE_TIME_INFO = "DATE_TIME_INFO";
